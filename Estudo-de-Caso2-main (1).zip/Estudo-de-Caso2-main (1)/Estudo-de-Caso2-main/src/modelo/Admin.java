package modelo;

public class Admin {
	
	private String usuarioAdmin = "AntonioCarlosNicolodi";
	private String senhaAdmin = "123456789";
	
	public String getUsuarioAdmin() {
		return usuarioAdmin;
	}
	public void setUsuarioAdmin(String usuarioAdmin) {
		this.usuarioAdmin = usuarioAdmin;
	}
	public String getSenhaAdmin() {
		return senhaAdmin;
	}
	public void setSenhaAdmin(String senhaAdmin) {
		this.senhaAdmin = senhaAdmin;
	}

}
